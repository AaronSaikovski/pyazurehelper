## A Python boilerplate/starter project.

Based on various sources and please feel free to change to suit your environment/style. ;-)