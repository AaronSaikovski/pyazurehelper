#!/usr/bin/env python
""" A python script to deploy an Azure Bicep or ARM Template.

MIT License
Copyright (c) 2023 Aaron Saikovski

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""
__author__ = "Aaron Saikovski"
__contact__ = "asaikovski@outlook.com"
__date__ = "2023/03/03"
__license__ = "MIT"
__maintainer__ = "developer"
__status__ = "Testing"
__version__ = "0.0.1"

import os
import sys
#from azure.cli.core import get_default_cli
from dotenv import load_dotenv
import console_helper

import azure_deploy

from azure_deploy import Deploy


def main() -> None:
    """Main function.

    Returns
    -------
    None
    """
    # check we are running the deploy script from a virtual environment.
    # if sys.prefix != sys.base_prefix:
    #     console_helper.print_confirmation_message("You are running in a virtual environment.")
    # else:
    #     console_helper.print_warning_message("This is not a virtual environment!")
    #     print('Run the following command to create a virtual environment.')
    #     console_helper.print_command_message("python -m venv venv")
    #     print('Then activate the virtual environment')
    #     sys.exit()

    # take environment variables from .env.
    load_dotenv()

    # get the cli instance
    #az_cli = get_default_cli()

    # Retrieve Azure values from environment variables.
    subscription_id: str = os.getenv("SUBSCRIPTION_ID")
    resource_group_name = os.getenv("RESOURCE_GROUP_NAME")
    location = os.getenv("LOCATION")
    environment = os.getenv("ENVIRONMENT")

    # Login to Azure for the given Subscription
    # azure_login.check_azure_login(az_cli, subscription_id)
    
    # # get the environment variables from the .env file.
    template_parameters = {
        'environment': {'value': environment},
        'location': {'value': location},
        'resource_group_name': {'value':resource_group_name}
    }
    
    # Call the deploy class
    deploy = Deploy(subscription_id,resource_group_name,location)
    deploy.deploy_resource_group()
    #deploy.deploy_resource_template("main.bicep", template_parameters)
    deploy.destroy_resource_group()


    #do the deployment
    # azdeploy.deploy_template(az_cli,
    #                 "main.bicep", 
    #                 location,
    #                 template_parameters)

# Main check
if __name__ == "__main__":
    main()
    