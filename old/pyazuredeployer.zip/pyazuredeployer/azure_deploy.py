#!/usr/bin/env python
# MIT License
# Copyright (c) 2023 Aaron Saikovski
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""
Deploys Azure resources using the Azure Python SDK - Built using Anaconda/Miniconda
"""
import os
import os.path
import sys
import json

from azure.identity import AzureCliCredential
from azure.mgmt.resource import ResourceManagementClient
from azure.mgmt.resource.resources.models import DeploymentMode

import console_helper
import azure_helper


__author__ = "Aaron Saikovski"
__contact__ = "asaikovski@outlook.com"
__date__ = "2023-03-16"
__license__ = "MIT"
__maintainer__ = "developer"
__status__ = "Testing"
__version__ = "0.0.1"


class Deploy():
    '''
    Main deployment class - Deploys Azure resources    
    Perform the deployment of Azure resources
   
    '''
    def __init__(self, subscription_id: str, resource_group_name: str, location: str) -> None:
        
        """Init function.

        Returns
        -------
        ResourceManagementClient instance based on credential and SubscriptionId
        """        
         # Acquire a credential object using CLI-based authentication.
        azure_cli_credential = AzureCliCredential()
        self.credentials = azure_cli_credential
        
        #local variables
        self.subscription_id = subscription_id
        self.resource_group_name = resource_group_name
        self.location = location
        
        # Check if SubscriptionID is valid
        if azure_helper.check_valid_subscription_id(self.subscription_id):
            # Obtain the management object for resources.
            self.resource_client = ResourceManagementClient(self.credentials, self.subscription_id)
            #print(f"logged in")
        else:
            console_helper.print_error_message("##ERROR - Invalid SubscriptionID!")
            sys.exit(-1) 
            
    def deploy_resource_group(self) -> None:
        """Deploys a new Azure resource group
        Parameters
        ----------
        taken from class constructor

        Returns
        -------
        nothing
            Displays output status of the Resource group deployment.
        """
        rg_result = self.resource_client.resource_groups.create_or_update(self.resource_group_name, {"location": self.location})
        # print(f"Provisioned resource group {rg_result.name} in the {rg_result.location} region"
        # )
    

    def deploy_resource_template(self, template_path: str, template_parameters: dict) -> None:
        """Deploys a template to the resource group
        Parameters
        ----------
        taken from class constructor

        Returns
        -------
        nothing
            Displays output status of the Resource group deployment.
        """     
            
        # check the file path exists
        if os.path.isfile(template_path):
            # build properties
            deployment_properties = {
                'mode': DeploymentMode.INCREMENTAL,
                'template': template_path,
                'parameters': template_parameters
             }
            
            # str_temp = json.dumps(deployment_properties)
            # print(deployment_properties)

            # Do the deployment
            # template_result = self.resource_client.deployments.begin_create_or_update(
            #     self.resource_group_name,
            #     'azure-sample',
            #     deployment_properties
            # )
            
            template_result = self.resource_client.deployments.begin_create_or_update(self.resource_group_name,
                'azure-sample',{'parameters': json.dumps(template_parameters)})
       
        else:
            console_helper.print_error_message(f"##ERROR - Deployment Template {template_path} not found>!")
            sys.exit(-1)

    
    def destroy_resource_group(self) -> None:
        """Destroys the Azure resource group
        Parameters
        ----------
        taken from class constructor

        Returns
        -------
        nothing
            Displays output status of the Resource group deployment.
        """
        self.resource_client.resource_groups.begin_delete(self.resource_group_name)
    
